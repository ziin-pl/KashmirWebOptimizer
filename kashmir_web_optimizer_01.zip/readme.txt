 This is a very early Beta version. It was tested and it gave good results, but
          it cannot be guaranted it won't produce corrupted files, so:

      ALWAYS CHECK OUTPUT, OPTIMIZED FILES BEFORE DELETING ORIGINAL FILES

                              also remember to:

                 NOT SAVE OUTPUT FILES THE INPUT DIRECTORY

      and it would be best if the output directory is empty. Just in case.
If you find that Kashmir Web Optimizer produced a corrupted file- please send me
          both input and output file via e-mail at: tomek@przeslij.pl