About plugins:
------------------------------------------------------------------------
ESC.wsf		This is ESC 1.14- javascript compressor by Saltstorm.
		It is released under GNU/GPL license:
		http://www.gnu.org/copyleft/gpl.txt
		Program's homepage: http://www.saltstorm.net/

jhead.exe	This is JHead 2.8 by Matthias Wander. It is licensed
		under Public Domain license. Program's homepage:
		http://www.sentex.net/~mwandel/jhead/

pngout.exe	This is PngOut (Arp 22/2007) by Ken Silverman. Its
		license is here:
		http://www.advsys.net/ken/utils.htm#pngoutkziplicense
		Program's homepage: http://www.advsys.net/ken/utils.htm